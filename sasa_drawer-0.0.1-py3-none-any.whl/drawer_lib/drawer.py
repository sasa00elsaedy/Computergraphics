import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *

import random


vertices = (    (1, -1, -1), (1, 1, -1), (-1, 1, -1),  (-1, -1, -1),  (1, -1, 1),  (1, 1, 1),  (-1, -1, 1),  (-1, 1, 1)    )

def get_cube_edges():
    return (
        (0, 1),
        (0, 3),
        (0, 4),
        (2, 1),
        (2, 3),
        (2, 7),
        (6, 3),
        (6, 4),
        (6, 7),
        (5, 1),
        (5, 4),
        (5, 7)
    )

def get_cube_vertices(a:int, vertices = vertices):
    scaled_vertices = []
    for vertex in vertices:
        scaled_vertex = tuple(a * coordinate for coordinate in vertex)
        scaled_vertices.append(scaled_vertex)
    return scaled_vertices


def sasa_drawer(draw_function,caption="sasa drawer" ,display=(800, 600), use_perspective=True, bg_color=(0.0, 0.0, 0.0, 0.0), coordinate_system=(-200, 200, -200, 200), rotate=False, **kwargs):
    pygame.init()
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    pygame.display.set_caption(caption)
    glClearColor(*bg_color)
    
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    if use_perspective:
        gluPerspective(45, (display[0] / display[1]), 0.1, 50.0)
        glTranslatef(0.0, 0.0, -5)
    else:
        gluOrtho2D(*coordinate_system)
    
    glMatrixMode(GL_MODELVIEW)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        if rotate:
            glRotatef(1, 3, 1, 1)
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        draw_function(**kwargs)
        
        pygame.display.flip()
        pygame.time.wait(10)






    